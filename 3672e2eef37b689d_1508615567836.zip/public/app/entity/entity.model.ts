export class EntityModel
{   
    id     :    string; 
    esetname     :    string; 
    entityname     :    string; 
    fieldname     :    string; 
    datatype     :    string; 
    required     :    boolean;
}
