import { Injectable } from '@angular/core';

import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';

import { app_service } from '../app.service';
import { FeedbackModel } from './feedback.model';

@Injectable()
export class FeedbackService {

    constructor(private http: Http, public gsvc: app_service) {

    }

    // private headers = new Headers({ 'Content-Type': 'application/json' });
    private FeedbackUrl = this.gsvc.BaseURL + '/feedback'; //api/feedbacks
    me;

    options() {
        let headers = new Headers({
            'Content-Type': 'application/json',
            Accept: 'application/json'
        });
        return new RequestOptions({ headers: headers, withCredentials: true });

    }


    resget() {
        return this.http.get(this.FeedbackUrl, this.options())
            .toPromise()
            .then((response) => {
                return <FeedbackModel[] > response.json();
            })
            .catch((res: Response) => this.handleError(res));
    }


    // Get 
    query(): Promise <FeedbackModel[] > {
        return this.http.get(this.FeedbackUrl, this.options())
            .toPromise()
            .then((response) => {
                return <FeedbackModel[] > response.json();
            })
            .catch((res: Response) => this.handleError(res));
    }


    get(id: number): Promise <FeedbackModel > {
        const url = `${this.FeedbackUrl
    } / ${id } `;
        return this.http.get(url)
            .toPromise()
            .then(response => response.json() as FeedbackModel)
            .catch(this.handleError);
    }


    save(FeedbackModel: FeedbackModel): Promise<FeedbackModel> {
        return this.http
            .post(this.FeedbackUrl, JSON.stringify(FeedbackModel), this.options())
            .toPromise()
            .then(res => res.json() as FeedbackModel)
            .catch(this.handleError);
    }
 

    delete(FeedbackModel: FeedbackModel): Promise<void> {
        const url = `${this.FeedbackUrl}/${FeedbackModel.id}`;
    return this.http
        .delete(url, this.options())
        .toPromise()
        .then(() => null)
        .catch(this.handleError);
}
 

    private handleError = (error: any): Promise<any> => {
        console.log("error...............",error);
    // this.gsvc.showToast('An error occurred');
    return Promise.reject(error.message || error);
}
}