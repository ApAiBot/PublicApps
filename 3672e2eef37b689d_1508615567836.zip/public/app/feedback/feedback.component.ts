import { Component, OnInit, Input, ViewChild, ViewContainerRef } from '@angular/core';
import { MdSidenav, MdDialog, MdDialogConfig } from "@angular/material";
   
 
import { app_service, confirmDialog } from '../app.service';
import { FeedbackService } from './feedback.service';

import { FeedbackModel } from './feedback.model';

declare var ace: any; 

@Component({
  selector: 'feedback',
  templateUrl: './feedback.html',
  styleUrls: ['./feedback.css'],
  providers: [  FeedbackService]
})
export class FeedbackComponent implements OnInit {

searchFeedbacks;
showComments;
hideComments;
codetext;
   feedbacks = [];
  newFeedback = new FeedbackModel();

  title;  

  @ViewChild('feedbacksidenav') feedbacksidenav: MdSidenav;
 
  isDarkTheme = false;
  textm;
  options;
  onChange;
  //remove
  me; 


  constructor(public gsvc: app_service, public dialog: MdDialog, public vcr: ViewContainerRef, private feedback: FeedbackService) {
    this.textm = 'test';
    this.options = { printMargin: false, mode: 'javascript' };
    this.onChange = (data) => {
      // this.content
      console.log(data);

    }
  }

  ngOnInit() {
 
  }
 

  togglenav() {
    // this.sidenav.toggle();
    this.feedbacksidenav.toggle();
  };

  reset() {
    this.newFeedback = new FeedbackModel();
     
  };

  // List of this collection 
  listView() { }

  // Save new or edited item
  save() {
    var i = -1;
    var j = 0; 
    this.feedbacks.forEach(feedback => {
      if (feedback.id === this.newFeedback.id) {
        i = j;

        console.log('i...........................',i);
      }
      j = j++;
    });
 
    this.feedback.save(this.newFeedback).then(success  => {
      console.log('success feedback',success);
      
      if (i >= 0) {
        this.feedbacks[i] = success;
      } else {
        this.feedbacks.push(success);
      };

      this.gsvc.showToast('Saved!');

      this.reset();
    },   (err)=> {
      if (err.status === 401) {
        this.gsvc.showToast('Unauthorized'); 
      } else { 
        this.gsvc.showToast('An error occured!');
      }
    });
     
  };

  // Edit selected item from ListView
  edit(feedback) {
    this.newFeedback = feedback;
    this.togglenav();

  };

  //Delete one or more items in the collection 
  delete($event, feedback) {
    console.log(' this.feedbacks-------------', this.feedbacks);
    let msgdata = { title: "Delete", message: "Are you sure you want to delete this feedback?", option1: "Yes", option2: "No" };
    let dialogRef = this.dialog.open(confirmDialog, { data: msgdata });
    dialogRef.afterClosed().subscribe(result => {
      console.log('result-----------: ', result);
      if (result === "Yes") {

        this.feedback.delete(feedback).then( (success)=> {
          var i = this.feedbacks.indexOf(feedback);
          this.feedbacks.splice(i, 1);
          this.gsvc.showToast('deleted.');
          if (feedback.id === this.newFeedback.id) {
            // delete this.comments;
            // this.hideComments();
          }
          this.reset();
        }, (err)  => {
          console.log(err);
          if (err.status === 401) {
            this.gsvc.showToast('Unauthorized.'); 
          } else {
            console.log(err);
            this.gsvc.showToast('An error occured!');

          }
        });
      }
      //  Endif

    });

  };
 
  openDialog() { 

  } 
}
