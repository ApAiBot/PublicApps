export class FeedbackModel
{   
    id     :    string; 
    email     :    string; 
    subject     :    string; 
    Date     :    number;
}
