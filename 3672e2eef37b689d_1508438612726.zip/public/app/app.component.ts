import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { MdSidenav, MdDialog, MdDialogConfig } from "@angular/material"; 
import { app_service } from './app.service';
 

@Component({
  selector: 'settings-dialog',
  template: `
    <label>Would you like to set up app options???</label>
    <md-slide-toggle></md-slide-toggle>
  `
})
export class SettingsDialog {}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'
  ],
  providers: []
})
export class AppComponent implements OnInit {

  public posts;
  title;
  data: any;
  @ViewChild('sidenav') sidenav: MdSidenav;

  isDarkTheme = false;
  public me;
  constructor(public gsvc: app_service, public dialog: MdDialog, public vcr: ViewContainerRef) {
  }

  ngOnInit() {
    let newAccount = { "username": "user", "password": "password" };
  }

  ngOnDestroy() {
 
  }

  openDialog() {
    const config = new MdDialogConfig();
    config.viewContainerRef = this.vcr;
    this.dialog.open(SettingsDialog, config);
  }

  goHome() { }
}

