import { Component, OnInit, Input, ViewChild, ViewContainerRef } from '@angular/core';
import { MdSidenav, MdDialog, MdDialogConfig } from "@angular/material";
   
 
import { app_service, confirmDialog } from '../app.service';
import { LoginService } from './login.service';

import { LoginModel } from './login.model';

declare var ace: any; 

@Component({
  selector: 'login',
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
  providers: [  LoginService]
})
export class LoginComponent implements OnInit {

searchLogins;
showComments;
hideComments;
codetext;
   logins = [];
  newLogin = new LoginModel();

  title;  

  @ViewChild('loginsidenav') loginsidenav: MdSidenav;
 
  isDarkTheme = false;
  textm;
  options;
  onChange;
  //remove
  me; 


  constructor(public gsvc: app_service, public dialog: MdDialog, public vcr: ViewContainerRef, private login: LoginService) {
    this.textm = 'test';
    this.options = { printMargin: false, mode: 'javascript' };
    this.onChange = (data) => {
      // this.content
      console.log(data);

    }
  }

  ngOnInit() {
 
  }
 

  togglenav() {
    // this.sidenav.toggle();
    this.loginsidenav.toggle();
  };

  reset() {
    this.newLogin = new LoginModel();
     
  };

  // List of this collection 
  listView() { }

  // Save new or edited item
  save() {
    var i = -1;
    var j = 0; 
    this.logins.forEach(login => {
      if (login.id === this.newLogin.id) {
        i = j;

        console.log('i...........................',i);
      }
      j = j++;
    });
 
    this.login.save(this.newLogin).then(success  => {
      console.log('success login',success);
      
      if (i >= 0) {
        this.logins[i] = success;
      } else {
        this.logins.push(success);
      };

      this.gsvc.showToast('Saved!');

      this.reset();
    },   (err)=> {
      if (err.status === 401) {
        this.gsvc.showToast('Unauthorized'); 
      } else { 
        this.gsvc.showToast('An error occured!');
      }
    });
     
  };

  // Edit selected item from ListView
  edit(login) {
    this.newLogin = login;
    this.togglenav();

  };

  //Delete one or more items in the collection 
  delete($event, login) {
    console.log(' this.logins-------------', this.logins);
    let msgdata = { title: "Delete", message: "Are you sure you want to delete this login?", option1: "Yes", option2: "No" };
    let dialogRef = this.dialog.open(confirmDialog, { data: msgdata });
    dialogRef.afterClosed().subscribe(result => {
      console.log('result-----------: ', result);
      if (result === "Yes") {

        this.login.delete(login).then( (success)=> {
          var i = this.logins.indexOf(login);
          this.logins.splice(i, 1);
          this.gsvc.showToast('deleted.');
          if (login.id === this.newLogin.id) {
            // delete this.comments;
            // this.hideComments();
          }
          this.reset();
        }, (err)  => {
          console.log(err);
          if (err.status === 401) {
            this.gsvc.showToast('Unauthorized.'); 
          } else {
            console.log(err);
            this.gsvc.showToast('An error occured!');

          }
        });
      }
      //  Endif

    });

  };
 
  openDialog() { 

  } 
}
