// require deployd
var deployd = require('deployd');

// configure database etc. 
var server = deployd({
  port: process.env.PORT || 2403,
  env: process.env.ENV || 'development',

  db: {
    //Connection UN / PWD  should not contain an '@' included.
    connectionString: 'mongodb://localhost:27017/MMUDB'
    //  mongo --port 27017 -u "myUserAdmin" -p "abc123" --authenticationDatabase "admin"
  }
});


// start the server
server.listen();

// debug
server.on('listening', function () {
  console.log("MMU DPD Server is listening on port: " + (process.env.PORT || 2403));
});

// Deployd requires this
server.on('error', function (err) {
  console.error(err);
  process.nextTick(function () { // Give the server a chance to return an error
    process.exit();
  });
});
