// require deployd
var deployd = require('deployd');
 
// configure database etc. 
var server = deployd({
  port: process.env.PORT || 2403,
  env: process.env.ENV || 'development',
//   db: {
// //    connectionString: 'mongodb://localhost:27017/interface'
//       connectionString: 'mongodb://localhost:27017/MMUDB'
//   },
//   // db: process.env.connectionString || 'mongodb://localhost:27017/MMUDB'

 db: {
   //Connection UN / PWD  should not contain an '@' included.
    connectionString: 'mongodb://MMUDBAdmin:MMUDBAdminpwd_123@localhost:27017/MMUDB'
//  connectionString: 'mongodb://localhost:27017/MMUDB'
//  mongo --port 27017 -u "myUserAdmin" -p "abc123" --authenticationDatabase "admin"
      // olld connectionString: 'mongodb://mmu:t8BoHyOUEW8jeKpNuyZ1nJUtO8KYkrh5fR8B04SBJVlGGd3qsAujdDSnyTzNblcRYiZZYtQfQDLsyhwo8CnvXA==@mmu.documents.azure.com:10250/?ssl=true'
// connectionString: 'mongodb://mmudocdb:P8SbFrfXiGYkNgaqVNcr8oWqMxMMm72iaRCUyyKP3RRVhYrknDPcPv26jG4Gch1dn0WwwL0Uc9jtVOqf8sCT4Q==@mmudocdb.documents.azure.com:10250/?ssl=true'
  }
});
  
 
// start the server
server.listen();
 
// debug
server.on('listening', function() {
  console.log("MMU DPD Server is listening on port: " + (process.env.PORT || 2403));
});
 
// Deployd requires this
server.on('error', function(err) {
  console.error(err);
  process.nextTick(function() { // Give the server a chance to return an error
    process.exit();
  });
});