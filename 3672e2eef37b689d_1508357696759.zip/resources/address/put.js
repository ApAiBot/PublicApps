this.lastmodby = me.id;
this.lastmod = Date.now();
//if(this.userId !== me.id && !me.posts){
//    cancel("Unauthorized", 401);
//}