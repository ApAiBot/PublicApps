this.userId = me.id;
this.creator = me.id;
this.created = Date.now();
this.lastmodby = me.id;
this.lastmod = Date.now();