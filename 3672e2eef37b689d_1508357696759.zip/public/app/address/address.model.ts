export class AddressModel
{   
    id     :    string; 
    address1     :    string; 
    address2     :    string; 
    city     :    string; 
    zip     :    number; 
    Date     :    number;
}
