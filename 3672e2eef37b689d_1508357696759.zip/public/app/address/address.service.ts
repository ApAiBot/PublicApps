import { Injectable } from '@angular/core';

import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';

import { app_service } from '../app.service';
import { AddressModel } from './address.model';

@Injectable()
export class AddressService {

    constructor(private http: Http, public gsvc: app_service) {

    }

    // private headers = new Headers({ 'Content-Type': 'application/json' });
    private AddressUrl = this.gsvc.BaseURL + '/address'; //api/addresses
    me;

    options() {
        let headers = new Headers({
            'Content-Type': 'application/json',
            Accept: 'application/json'
        });
        return new RequestOptions({ headers: headers, withCredentials: true });

    }


    resget() {
        return this.http.get(this.AddressUrl, this.options())
            .toPromise()
            .then((response) => {
                return <AddressModel[] > response.json();
            })
            .catch((res: Response) => this.handleError(res));
    }


    // Get 
    query(): Promise <AddressModel[] > {
        return this.http.get(this.AddressUrl, this.options())
            .toPromise()
            .then((response) => {
                return <AddressModel[] > response.json();
            })
            .catch((res: Response) => this.handleError(res));
    }


    get(id: number): Promise <AddressModel > {
        const url = `${this.AddressUrl
    } / ${id } `;
        return this.http.get(url)
            .toPromise()
            .then(response => response.json() as AddressModel)
            .catch(this.handleError);
    }


    save(AddressModel: AddressModel): Promise<AddressModel> {
        return this.http
            .post(this.AddressUrl, JSON.stringify(AddressModel), this.options())
            .toPromise()
            .then(res => res.json() as AddressModel)
            .catch(this.handleError);
    }
 

    delete(AddressModel: AddressModel): Promise<void> {
        const url = `${this.AddressUrl}/${AddressModel.id}`;
    return this.http
        .delete(url, this.options())
        .toPromise()
        .then(() => null)
        .catch(this.handleError);
}
 

    private handleError = (error: any): Promise<any> => {
        console.log("error...............",error);
    // this.gsvc.showToast('An error occurred');
    return Promise.reject(error.message || error);
}
}