import { Injectable }    from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import {TreeNode} from 'primeng/components/common/api';

@Injectable()
export class NodeService {
    
    constructor(private http: Http) {}

    getFiles() {
        return this.http.get('/../assets/resources/files.json')
                    .toPromise()
                    .then(res => <TreeNode[]> res.json().data)
                     
    }

    getWeather(){
 
         return this.http.get( 'http://ded9b8cb.ngrok.io/weather')
                    .toPromise()
                    .then(res => <TreeNode[]> res.json().data)
                    .then(data => { 
                        // console.log('data',data);
                        return data; });
    }
}
