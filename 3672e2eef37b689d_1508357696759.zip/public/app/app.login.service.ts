// import { Injectable } from '@angular/core'; 
// @Injectable()
// export class LoginService {
//   getHeroes(): Promise<Hero[]> {
//     return Promise.resolve(HEROES);
//   }
// }