import { Injectable } from '@angular/core';

import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';

import { app_service } from '../app.service';
import { LoginModel } from './login.model';

@Injectable()
export class LoginService {

    constructor(private http: Http, public gsvc: app_service) {

    }

    // private headers = new Headers({ 'Content-Type': 'application/json' });
    private LoginUrl = this.gsvc.BaseURL + '/login'; //api/logins
    me;

    options() {
        let headers = new Headers({
            'Content-Type': 'application/json',
            Accept: 'application/json'
        });
        return new RequestOptions({ headers: headers, withCredentials: true });

    }


    resget() {
        return this.http.get(this.LoginUrl, this.options())
            .toPromise()
            .then((response) => {
                return <LoginModel[] > response.json();
            })
            .catch((res: Response) => this.handleError(res));
    }


    // Get 
    query(): Promise <LoginModel[] > {
        return this.http.get(this.LoginUrl, this.options())
            .toPromise()
            .then((response) => {
                return <LoginModel[] > response.json();
            })
            .catch((res: Response) => this.handleError(res));
    }


    get(id: number): Promise <LoginModel > {
        const url = `${this.LoginUrl
    } / ${id } `;
        return this.http.get(url)
            .toPromise()
            .then(response => response.json() as LoginModel)
            .catch(this.handleError);
    }


    save(LoginModel: LoginModel): Promise<LoginModel> {
        return this.http
            .post(this.LoginUrl, JSON.stringify(LoginModel), this.options())
            .toPromise()
            .then(res => res.json() as LoginModel)
            .catch(this.handleError);
    }
 

    delete(LoginModel: LoginModel): Promise<void> {
        const url = `${this.LoginUrl}/${LoginModel.id}`;
    return this.http
        .delete(url, this.options())
        .toPromise()
        .then(() => null)
        .catch(this.handleError);
}
 

    private handleError = (error: any): Promise<any> => {
        console.log("error...............",error);
    // this.gsvc.showToast('An error occurred');
    return Promise.reject(error.message || error);
}
}