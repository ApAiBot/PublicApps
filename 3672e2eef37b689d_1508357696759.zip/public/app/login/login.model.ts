export class LoginModel
{   
    id     :    string; 
    username     :    string; 
    password     :    string;
}
