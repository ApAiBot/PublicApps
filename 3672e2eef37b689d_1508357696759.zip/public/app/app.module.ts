import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http'; 
import {
  MdInputModule, MdListModule,
  MdSidenavModule, MdDialogModule, MdMenuModule, MdToolbarModule,
  MdTabsModule, MdIconModule, MdButtonModule, MdCheckboxModule, MdSelectModule, MdSnackBarModule
} from "@angular/material";
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'; 
import { confirmDialog } from './app.service';
import { app_service  } from './app.service';
//Import custom components
import { AppComponent, SettingsDialog } from './app.component'; 

 import { AddressComponent } from './address/address.component'; 
import { EntityComponent } from './entity/entity.component'; 
import { LoginComponent } from './login/login.component'; 
 

@NgModule({
  declarations: [
    AppComponent,        AddressComponent,       EntityComponent,       LoginComponent,     SettingsDialog, confirmDialog
  ],
  entryComponents: [
    AppComponent,
    SettingsDialog, confirmDialog
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule, //angular 4
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      { path: '', redirectTo: '/addressComponent', pathMatch: 'full' },
              { path: 'address', component: AddressComponent },       
                { path: 'entity', component: EntityComponent },       
                { path: 'login', component: LoginComponent },       
          
        { path: '**', redirectTo: '' }   
    ]),
    MdInputModule, MdListModule,
    MdSidenavModule, MdDialogModule, MdMenuModule, MdToolbarModule,
    MdTabsModule, MdIconModule, MdButtonModule, MdCheckboxModule, MdSelectModule, MdSnackBarModule 
  ],
  providers: [ app_service],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
