import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http'; 
import {
  MdInputModule, MdListModule,
  MdSidenavModule, MdDialogModule, MdMenuModule, MdToolbarModule,
  MdTabsModule, MdIconModule, MdButtonModule, MdCheckboxModule, MdSelectModule, MdSnackBarModule
} from "@angular/material";
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'; 
import { confirmDialog } from './app.service';
import { app_service  } from './app.service';
//Import custom components
import { AppComponent, SettingsDialog } from './app.component'; 

 import { SearchkeyComponent } from './searchkey/searchkey.component'; 
import { SearchlistComponent } from './searchlist/searchlist.component'; 
 

@NgModule({
  declarations: [
    AppComponent,        SearchkeyComponent,       SearchlistComponent,     SettingsDialog, confirmDialog
  ],
  entryComponents: [
    AppComponent,
    SettingsDialog, confirmDialog
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule, //angular 4
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      { path: '', redirectTo: '/searchkeyComponent', pathMatch: 'full' },
              { path: 'searchkey', component: SearchkeyComponent },       
                { path: 'searchlist', component: SearchlistComponent },       
          
        { path: '**', redirectTo: '' }   
    ]),
    MdInputModule, MdListModule,
    MdSidenavModule, MdDialogModule, MdMenuModule, MdToolbarModule,
    MdTabsModule, MdIconModule, MdButtonModule, MdCheckboxModule, MdSelectModule, MdSnackBarModule 
  ],
  providers: [ app_service],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
