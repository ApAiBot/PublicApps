export class SearchlistModel
{   
    word     :    string; 
    detail     :    string;
}
