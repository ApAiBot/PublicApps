export class SearchkeyModel
{   
    searchkey     :    string;
}
